# information_retrieval_system

# HOW TO USE OUR SEARCH ENGINE

First fork the repository.

WITH GUI:

Open the terminal.

Change directories into the project's directory.

From here create a new virtual environment by using command - python -m venv .venv

Now change directories into ./.venv/Scripts and run command - activate

This should change your terminal line to start with (venv)

pip install <"dependency_name"> or python -m pip install <"dependency_name"> the following:

streamlit, bs4, lxml, nltk

Finally, run the command - streamlit run gui.py - from the projects directory (cd ..  until you are back in the project directory)


WITHOUT GUI:

Open the terminal.

Change directories into the project's directory.

Run command - python main.py | python3 main.py

HAPPY SEARCHING!